このプログラムはGPLライセンスに基づき提供されています。このプログラム
を複製、改変または再配布する場合はGPLライセンスに従ってご利用ください。

This program is provided under the General Public License (GPL).
If you replicate, modify and redistribute this program, you must use it under
the General Public License (GPL).


このプログラムを構成する一部のプログラムにはMIT のライセンスに基づく
コードが使用されています。

Part of this program uses the code under the MIT license.
